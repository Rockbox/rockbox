/*****************************************************************************
 *
 *  scramble.c - Scramble Archos firmware
 *
 *  Copyright (C) 2001 Bj�rn Stenberg.
 *
 *  This program is free software; you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License as published by the
 *  Free Software Foundation; version 2 of the License.
 *
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#define	MIN_LENGTH	51200	/* minimum output length */

int main (int argc, char** argv)
{
    unsigned long length,in_length,i,slen;
    unsigned char *inbuf,*outbuf;
    unsigned short crc=0;
    unsigned char header[6];
    FILE* file;

    if (argc < 3) {
       printf("usage: %s <input file> <output file>\n",argv[0]);
       return -1;
    }

    /* open file */
    file = fopen(argv[1],"rb");
    if (!file) {
       perror(argv[1]);
       return -1;
    }
    fseek(file,0,SEEK_END);
    in_length = ftell(file);
    fseek(file,0,SEEK_SET);

	/* pad to multiple of 4, minimum of MIN_LENGTH */
    length = (in_length+3) & ~3;
    if (length < MIN_LENGTH)
    	length = MIN_LENGTH;

    inbuf = malloc(length);
    outbuf = malloc(length);
    if ( !inbuf || !outbuf ) {
       printf("out of memory!\n");
       return -1;
    }
    memset (inbuf, 0, length);

    /* read file */
    i=fread(inbuf,1,in_length,file);
    if ( !i ) {
       perror(argv[1]);
       return -1;
    }
    fclose(file);

    /* scramble */
    slen = length/4;
    for (i = 0; i < length; i++) {
       unsigned long addr = (i >> 2) + ((i % 4) * slen);
       unsigned char data = inbuf[i];
       data = ~((data << 1) | ((data >> 7) & 1)); /* poor man's ROL */
       outbuf[addr] = data;
    }

    /* calculate checksum */
    for (i=0;i<length;i++)
       crc += inbuf[i];

    /* make header */
    header[0] = (length >> 24) & 0xff;
    header[1] = (length >> 16) & 0xff;
    header[2] = (length >> 8) & 0xff;
    header[3] = length & 0xff;
    header[4] = (crc >> 8) & 0xff;
    header[5] = crc & 0xff;

    /* write file */
    file = fopen(argv[2],"wb");
    if ( !file ) {
       perror(argv[2]);
       return -1;
    }
    if ( !fwrite(header,6,1,file) ) {
       perror(argv[2]);
       return -1;
    }
    if ( !fwrite(outbuf,length,1,file) ) {
       perror(argv[2]);
       return -1;
    }
    fclose(file);

    free(inbuf);
    free(outbuf);

    return 0;
}
