#include <stdio.h>
#include <conio.h>
#include <io.h>
#include <fcntl.h>
#include <memory.h>


#define NEEDEDSIZE				51200


//
// PrintHelp
//
// print out help text
//

int PrintHelp ()
{
    printf ("padit.exe - Version 1.00 (1/8/2002), by Felix Arends (edx@codeforce.d2g.com)\n\n"\

		"Usage: padit.exe <input file> <output file>\n\n"\

		"padit pads a compiled ARCHOS firmware mod, so it reaches the needed filesize\n"\
		"for higher firmware versions.\n\n");

	getch ();
	return 0;
}


//
// main
//
// program entry point
//

int main (
		  int argc,
		  char *argv [],
		  char *envp []
		  )
{
	if (argc != 2)
		return PrintHelp (); // print out help if not enough parameters

	int					hFile = open (argv[1], O_RDWR | O_BINARY);
	long				dwFileSize;

	_lseek (hFile, 0, SEEK_END);
	dwFileSize = _tell (hFile);

	char				*lpBuffer = new char [NEEDEDSIZE - dwFileSize];

	memset (lpBuffer, 0, NEEDEDSIZE - dwFileSize); // set buffer to 0
	if (write (hFile, lpBuffer, NEEDEDSIZE - dwFileSize) != NEEDEDSIZE - dwFileSize) // write buffer to file
	{
		printf ("Error 001: Could not write to file \"%s\"!\n\n", argv[1]);
		getch ();
		delete [] lpBuffer;
		return -1;
	}

	delete [] lpBuffer; // file padded successfully
    
	return 0;
}