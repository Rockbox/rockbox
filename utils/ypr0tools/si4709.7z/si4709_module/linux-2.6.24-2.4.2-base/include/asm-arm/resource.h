#ifndef _ARM_RESOURCE_H
#define _ARM_RESOURCE_H

#include <asm-generic/resource.h>

#endif
