#ifndef _ASMARM_DYNTICK_H
#define _ASMARM_DYNTICK_H

#include <asm/mach/time.h>

#endif /* _ASMARM_DYNTICK_H */
